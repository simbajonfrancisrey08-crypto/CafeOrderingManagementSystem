<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'cashier') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

$order_id = $_GET['id'] ?? 0;

// Fetch order info
$order = $conn->query("SELECT * FROM orders WHERE id = $order_id")->fetch_assoc();
if (!$order) {
    echo "Order not found.";
    exit;
}

// Fetch order items
$order_items = $conn->query("SELECT oi.*, m.name 
                             FROM order_items oi
                             LEFT JOIN meals m ON oi.meal_id = m.id
                             WHERE order_id = $order_id");
?>

<!DOCTYPE html>
<html>
<head>
<style>
        body {
            font-family: 'Montserrat', sans-serif;
           background-image: url('../images/dashboard - bg.jpg');
            background-size: cover;
            color: #fff;
            text-align: center;
            padding: 20px;
        }
</style>

    <title>Order Details</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2>Order #<?= isset($order['id']) ? $order['id'] : '-' ?> Details</h2>
    <a href="manage_orders.php">← Back to Orders</a><br><br>

    <p><strong>Order Type:</strong> <?= isset($order['order_type']) ? ucfirst($order['order_type']) : '-' ?></p>
    <p><strong>Table Number:</strong> <?= isset($order['table_id']) && $order['table_id'] != 0 ? $order['table_id'] : '-' ?></p>
    <p><strong>Total Amount:</strong> ₱<?= isset($order['total']) ? number_format((float)$order['total'], 2) : '0.00' ?></p>
    <p><strong>Created At:</strong> <?= isset($order['created_at']) ? $order['created_at'] : '-' ?></p>

    <h3>Items</h3>
    <table border="1" cellpadding="8" cellspacing="0">
        <tr>
            <th>Coffee</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Subtotal</th>
        </tr>
        <?php while ($item = $order_items->fetch_assoc()): ?>
            <tr>
                <td><?= isset($item['name']) ? $item['name'] : 'Unknown' ?></td>
                <td><?= isset($item['quantity']) ? $item['quantity'] : 0 ?></td>
                <td>₱<?= isset($item['price']) ? number_format((float)$item['price'], 2) : '0.00' ?></td>
                <td>₱<?= isset($item['price'], $item['quantity']) ? number_format($item['price'] * $item['quantity'], 2) : '0.00' ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
