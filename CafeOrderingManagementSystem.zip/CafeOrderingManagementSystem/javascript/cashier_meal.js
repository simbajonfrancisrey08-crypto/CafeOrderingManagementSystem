document.addEventListener("DOMContentLoaded", function () {

    const forms = document.querySelectorAll('form[action="add_to_cart.php"]');
    const notification = document.getElementById('cartNotification');

    if (!notification) {
        console.error("Notification div not found!");
        return;
    }

    forms.forEach(form => {

        const hint = form.querySelector('.click-hint');

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            const formData = new FormData(form);

            fetch('add_to_cart.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(() => {

                // ✅ SHOW NOTIFICATION
                notification.textContent = "🛒 Added to Cart!";
                notification.classList.add('show');

                setTimeout(() => {
                    notification.classList.remove('show');
                }, 1500);

                // optional hint
                if (hint) {
                    hint.style.display = 'block';

                    setTimeout(() => {
                        hint.style.display = 'none';
                    }, 3000);
                }

            })
            .catch(error => {
                console.error('Error:', error);
            });

        });

    });

});