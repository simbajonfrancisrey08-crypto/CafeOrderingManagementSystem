<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
include '../includes/db.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$table = $conn->query("SELECT * FROM tables WHERE id = $id")->fetch_assoc();
if (!$table) {
    echo "Table not found.";
    exit;
}

if (isset($_POST['update'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $status = $_POST['status'];

    // Update table details
    $conn->query("UPDATE tables SET table_number='$table_number', status='$status' WHERE id=$id");

    header("Location: manage_tables.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Table</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background:rgba(249, 253, 253);
            background-size: cover;
            color: #050505;
            text-align: center;
            padding: 20px;
        }
    </style>
</head>
<body>
    <h2>Edit Table</h2>
    <a href="manage_tables.php">← Back</a><br><br>

    <form method="POST">
        <label for="name">Table Name / No.</label>
        <input type="text" name="table_name" id="name" value="<?= htmlspecialchars($table['table_name']) ?>" required><br>

        <label for="status">Status</label>
        <select name="status" id="status" required>
            <option value="Available" <?= $table['status'] == 'Available' ? 'selected' : '' ?>>Available</option>
            <option value="Occupied" <?= $table['status'] == 'Occupied' ? 'selected' : '' ?>>Occupied</option>
        </select><br>

        <button type="submit" name="update">Update Table</button>
    </form>
</body>
</html>
