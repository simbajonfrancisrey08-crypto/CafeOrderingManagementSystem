<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
include '../includes/db.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

// Fetch the category
$result = $conn->query("SELECT * FROM categories WHERE id = $id");
if ($result->num_rows === 0) {
    echo "Category not found.";
    exit;
}
$category = $result->fetch_assoc();

// Fetch meals (coffee types) under this category
$types = $conn->query("SELECT name FROM meals WHERE category_id = $id");

// Update category
if (isset($_POST['update'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $conn->query("UPDATE categories SET name = '$name' WHERE id = $id");
    header("Location: manage_categories.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Category</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background:rgba(249, 253, 253);
            background-size: cover;
            color: #080808;
            text-align: center;
            padding: 20px;
        }
        ul.types {
    margin: 16px 0 24px 30px;
    padding: 0;
    list-style-type: disc;
    font-size: 15px;
    color: black;
    font-family: Arial, sans-serif;
    line-height: 1.6;
}

ul.types li {
    margin: 6px 0;
}

    </style>
</head>
<body>
    <h2>✏️ Edit Category</h2>
    <a href="manage_categories.php">← Back</a><br><br>

    <form method="POST">
        <input type="text" name="name" value="<?= htmlspecialchars($category['name']) ?>" required>
        <button type="submit" name="update">Update</button>
    </form>

    <h4>☕ Coffee Types under this Category:</h4>
    <ul class="types">
        <?php if ($types->num_rows > 0): ?>
            <?php while ($type = $types->fetch_assoc()): ?>
                <li><?= htmlspecialchars($type['name']) ?></li>
            <?php endwhile; ?>
        <?php else: ?>
            <li><em>No coffee types assigned to this category yet.</em></li>
        <?php endif; ?>
    </ul>
</body>
</html>
