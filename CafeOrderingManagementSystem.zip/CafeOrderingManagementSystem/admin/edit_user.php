<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
include '../includes/db.php';

$id = $_GET['id'] ?? 0;

// Fetch user info
$user = $conn->query("SELECT * FROM users WHERE id = $id")->fetch_assoc();
if (!$user) {
    echo "User not found.";
    exit;
}

// Optional: Prevent editing super admin (ID 1)
if ($id == 1 && $_SESSION['user_id'] != 1) {
    echo "You cannot edit the main admin account.";
    exit;
}

// Update user info
if (isset($_POST['update'])) {
    $username = $_POST['username'];
    $role = $_POST['role'];
    $password = $_POST['password'];

    if (!empty($password)) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $conn->query("UPDATE users SET username='$username', password='$hashed', role='$role' WHERE id=$id");
    } else {
        $conn->query("UPDATE users SET username='$username', role='$role' WHERE id=$id");
    }

    echo "<script>alert('User updated successfully.'); window.location='manage_users.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background:rgba(249, 253, 253);
            background-size: cover;
            color: #070606;
            text-align: center;
            padding: 20px;
        }
        input, select {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: none;
            width: 250px;
        }
        button {
            padding: 10px 20px;
            background-color: teal;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        a {
            display: inline-block;
            margin-bottom: 20px;
            color: #0e0c0c;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <h2>Edit User</h2>
    <a href="manage_users.php">← Back to Users</a><br><br>

    <form method="POST">
        <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
        <input type="password" name="password" placeholder="New Password (leave blank to keep current)">
        <select name="role" required>
            <option value="cashier" <?= $user['role'] == 'cashier' ? 'selected' : '' ?>>Cashier (Order Access)</option>
            <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin (Full Access)</option>
        </select>
        <br>
        <button type="submit" name="update">Update User</button>
    </form>
</body>
</html>
