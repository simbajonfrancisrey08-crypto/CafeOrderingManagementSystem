window.onload = function() {
    const urlParams = new URLSearchParams(window.location.search);
    const notif = document.getElementById('adminOrderMessage');

    if (!notif) return;

    // ✅ Item added to cart
    if (urlParams.has('added')) {
        notif.textContent = "🛒 Item added to cart!";
        notif.classList.add('show');

        setTimeout(() => {
            notif.classList.remove('show');
        }, 3000);
    }

    // (Optional: keep your old logic if you later use real orders)
    if (urlParams.has('new_completed')) {
        const orderId = urlParams.get('order_id') || '';
        notif.textContent = orderId
            ? `✅ Order #${orderId} completed.`
            : `✅ Order completed.`;

        notif.classList.add('show');

        setTimeout(() => {
            notif.classList.remove('show');
        }, 4000);
    }
};