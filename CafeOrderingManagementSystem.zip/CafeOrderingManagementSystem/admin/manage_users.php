<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
include '../includes/db.php';

// Add User
if (isset($_POST['add'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $conn->query("INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')");
    header("Location: manage_users.php");
    exit;
}

// Delete User
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    if ($id == 1) {
        echo "<script>alert('Cannot delete the main admin account.'); window.location='manage_users.php';</script>";
        exit;
    }
    $conn->query("DELETE FROM users WHERE id=$id");
    header("Location: manage_users.php");
    exit;
}

// Search
$search = $_GET['search'] ?? '';
$query = "SELECT * FROM users";
if (!empty($search)) {
    $query .= " WHERE username LIKE '%$search%'";
}
$users = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-image: url('../images/dashboard - bg.jpg');
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        input, select, button {
            padding: 10px;
            margin: 5px;
            border-radius: 5px;
            border: none;
        }
        table {
            width: 80%;
            margin: auto;
            background: #fff;
            color: #000;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
        }
        a.button {
            display: inline-block;
            padding: 8px 12px;
            background: #eee;
            color: black;
            border-radius: 5px;
            text-decoration: none;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<h2>Manage Users</h2>
<a href="dashboard.php" class="button">← Back to Dashboard</a>

<!-- Add User Form -->
<h3>Add New User</h3>
<form method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <select name="role" required>
        <option value="cashier">Cashier</option>
        <option value="admin">Admin</option>
    </select>
    <button type="submit" name="add">Add User</button>
</form>

<!-- Search Form -->
<form method="GET" style="margin-top: 20px;">
    <input type="text" name="search" placeholder="Search username..." value="<?= htmlspecialchars($search) ?>">
    <button type="submit">Search</button>
    <a href="manage_users.php" class="button">Reset</a>
</form>

<!-- Users Table -->
<br><hr><br>
<table>
    <tr>
        <th>Username</th>
        <th>Role</th>
        <th>Actions</th>
    </tr>
    <?php while ($row = $users->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['username']) ?></td>
        <td><?= ucfirst($row['role']) ?></td>
        <td>
            <a href="edit_user.php?id=<?= $row['id'] ?>">Edit</a>
            <?php if ($row['id'] != 1): ?>
                | <a href="manage_users.php?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this user?')">Delete</a>
            <?php else: ?>
                | <span style="color: gray;">Protected</span>
            <?php endif; ?>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
