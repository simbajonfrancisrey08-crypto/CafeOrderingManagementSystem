<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'cashier') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

$meals = $conn->query("SELECT * FROM meals");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Meals</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<h2>Available Meals</h2>
<a href="pos.php">Go to POS 🛒</a>
<div>
    <?php while ($meal = $meals->fetch_assoc()): ?>
        <div style="margin-bottom: 15px; border-bottom: 1px solid #ccc;">
            <p><strong><?= $meal['name'] ?></strong> - ₱<?= number_format($meal['price'], 2) ?></p>
            <form method="POST" action="pos.php">
                <input type="hidden" name="meal_id" value="<?= $meal['id'] ?>">
                <input type="hidden" name="quantity" value="1">
                <button type="submit" name="add">Add to Cart</button>
            </form>
        </div>
    <?php endwhile; ?>
</div>

</body>
</html>
