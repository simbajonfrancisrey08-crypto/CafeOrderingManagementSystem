<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

if (isset($_POST['add_meal'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category_id = $_POST['category_id'];

    // Handle image upload
    $imageName = $_FILES['image']['name'];
    $imageTmp = $_FILES['image']['tmp_name'];
    $imagePath = '../images/' . basename($imageName);

    if (move_uploaded_file($imageTmp, $imagePath)) {
        $conn->query("INSERT INTO meals (name, price, category_id, image) 
                      VALUES ('$name', '$price', '$category_id', '$imageName')");
        $success = "Meal added successfully!";
    } else {
        $error = "Failed to upload image.";
    }
}

// Fetch categories for dropdown
$categories = $conn->query("SELECT * FROM categories");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Meal</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2>Add New Meal</h2>
    <a href="manage_meals.php">← Back</a><br><br>

    <?php if (isset($success)) echo "<p style='color:green;'>$success</p>"; ?>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="POST" enctype="multipart/form-data">
        <label>Meal Name:</label><br>
        <input type="text" name="name" required><br><br>

        <label>Price:</label><br>
        <input type="number" name="price" required><br><br>

        <label>Category:</label><br>
        <select name="category_id" required>
            <?php while ($cat = $categories->fetch_assoc()): ?>
                <option value="<?= $cat['id'] ?>"><?= $cat['name'] ?></option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Image:</label><br>
        <input type="file" name="image" accept="image/*" required><br><br>

        <button type="submit" name="add_meal">Add Meal</button>
    </form>
</body>
</html>
