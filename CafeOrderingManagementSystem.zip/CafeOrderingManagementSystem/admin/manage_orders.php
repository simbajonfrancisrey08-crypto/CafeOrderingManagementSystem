<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

/* =========================
   MARK ORDER AS COMPLETED
========================= */
if (isset($_GET['complete'])) {
    $id = (int) $_GET['complete'];

    // Update order status
    $conn->query("UPDATE orders SET status = 'completed' WHERE id = $id");

    // Get order info
    $order = $conn->query("SELECT * FROM orders WHERE id = $id")->fetch_assoc();

    // If dine-in, free table
    if ($order && $order['order_type'] === 'dine-in' && !empty($order['table_id'])) {
        $tableId = (int)$order['table_id'];

        $conn->query("
            UPDATE tables 
            SET status = 'available' 
            WHERE id = $tableId
        ");
    }

    header("Location: manage_orders.php?completed=1");
    exit;
}

/* =========================
   DELETE ALL COMPLETED
========================= */
if (isset($_GET['delete_all_completed'])) {

    $result = $conn->query("SELECT id FROM orders WHERE status = 'completed'");

    while ($row = $result->fetch_assoc()) {
        $orderId = (int)$row['id'];
        $conn->query("DELETE FROM order_items WHERE order_id = $orderId");
    }

    $conn->query("DELETE FROM orders WHERE status = 'completed'");

    header("Location: manage_orders.php?deleted_all=1");
    exit;
}

/* =========================
   DELETE OLD COMPLETED (7 DAYS)
========================= */
if (isset($_GET['delete_old_completed'])) {

    $result = $conn->query("
        SELECT id 
        FROM orders 
        WHERE status = 'completed' 
        AND created_at < NOW() - INTERVAL 7 DAY
    ");

    while ($row = $result->fetch_assoc()) {
        $orderId = (int)$row['id'];
        $conn->query("DELETE FROM order_items WHERE order_id = $orderId");
    }

    $conn->query("
        DELETE FROM orders 
        WHERE status = 'completed' 
        AND created_at < NOW() - INTERVAL 7 DAY
    ");

    header("Location: manage_orders.php?deleted_old=1");
    exit;
}

/* =========================
   FETCH ORDERS
========================= */
$orders = $conn->query("
    SELECT o.*, t.table_name 
    FROM orders o 
    LEFT JOIN tables t ON o.table_id = t.id 
    ORDER BY o.id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Orders</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/notification.css">

    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-image: url('../images/dashboard - bg.jpg');
            background-size: cover;
            color: #fff;
            text-align: center;
            padding: 20px;
        }

        table {
            background-color: #fff;
            color: black;
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ccc;
        }

        .btn-clear {
            padding: 10px 15px;
            background-color: red;
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>

<body>

<!-- Notifications -->
<div class="notification" id="adminOrderMessage">✅ Order completed by cashier.</div>
<div class="notification" id="orderNotification">✅ Order marked as completed.</div>

<?php if (isset($_GET['deleted_all'])): ?>
    <div class="notification" style="background-color: #ff4d4d;">
        🗑️ All completed orders deleted.
    </div>
<?php endif; ?>

<?php if (isset($_GET['deleted_old'])): ?>
    <div class="notification" style="background-color: orange;">
        🧹 Old completed orders deleted.
    </div>
<?php endif; ?>

<h2>Manage Orders</h2>

<a href="dashboard.php" style="color:black;background:#fff;padding:8px;border-radius:6px;text-decoration:none;">
    ← Back to Dashboard
</a>

<br><br>

<form method="get" onsubmit="return confirm('Delete ALL completed orders?');">
    <button class="btn-clear" name="delete_all_completed">🗑 Clear All Completed</button>
</form>

<br>

<form method="get" onsubmit="return confirm('Delete old completed orders?');">
    <button class="btn-clear" style="background:orange;" name="delete_old_completed">
        🧹 Delete 7+ Days Old
    </button>
</form>

<table>
    <tr>
        <th>Type</th>
        <th>Table</th>
        <th>Total</th>
        <th>Status</th>
        <th>Created</th>
        <th>Action</th>
    </tr>

    <?php while ($row = $orders->fetch_assoc()): ?>
    <tr>
        <td><?= ucfirst($row['order_type']) ?></td>

        <td>
            <?= $row['order_type'] == 'dine-in'
                ? ($row['table_name'] ?? '-')
                : '—' ?>
        </td>

        <td>₱<?= number_format($row['total'] ?? 0, 2) ?></td>
        <td><?= ucfirst($row['status']) ?></td>
        <td><?= $row['created_at'] ?? '-' ?></td>

        <td>
            <?php if ($row['status'] === 'pending'): ?>
                <a href="?complete=<?= $row['id'] ?>" onclick="return confirm('Complete this order?')">
                    ✅ Complete
                </a>
            <?php else: ?>
                <span style="color:green;">✔ Done</span>
            <?php endif; ?>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<script src="../javascript/notification.js"></script>

</body>
</html>