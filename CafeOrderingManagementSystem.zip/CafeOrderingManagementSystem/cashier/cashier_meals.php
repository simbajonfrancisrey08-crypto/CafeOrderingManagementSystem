<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'cashier') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';

$categories = $conn->query("SELECT * FROM categories");

$query = "SELECT meals.*, categories.name AS cat_name 
          FROM meals 
          JOIN categories ON meals.category_id = categories.id 
          WHERE 1";

if ($search !== '') {
    $search = $conn->real_escape_string($search);
    $query .= " AND meals.name LIKE '%$search%'";
}

if ($category_filter !== '') {
    $category_filter = (int) $category_filter;
    $query .= " AND meals.category_id = $category_filter";
}

$query .= " ORDER BY meals.name ASC";
$meals = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Cashier - Coffees</title>

<style>
body {
    font-family: 'Montserrat', sans-serif;
    background-image: url('../images/dashboard - bg.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    background-attachment: fixed;
    color: #fff;
    text-align: center;
    padding: 20px;
}

.meal-card {
    display: inline-block;
    width: 230px;
    margin: 10px;
    padding: 15px;
    background: rgba(0,0,0,0.7);
    border-radius: 10px;
}

.meal-card {
    display: inline-block;
    width: 230px;
    margin: 10px;
    padding: 15px;
    background: rgba(0,0,0,0.7);
    border-radius: 10px;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    cursor: pointer;
}

/* 🔥 Hover effect (when not clicking yet) */
.meal-card:hover {
    transform: translateY(-8px) scale(1.03);
    box-shadow: 0 10px 25px rgba(0,0,0,0.4);
}

/* 🖱 Click effect */
.meal-card:active {
    transform: scale(0.97);
}

/* 🖼 Image zoom effect */
.meal-card img {
    transition: transform 0.3s ease;
}

.meal-card:hover img {
    transform: scale(1.05);
}

.meal-card img {
    width: 100%;
    height: 120px;
    object-fit: cover;
    border-radius: 8px;
}

button {
    margin-top: 10px;
    padding: 8px 12px;
    background: green;
    color: white;
    border: none;
    border-radius: 5px;
}

/* Smooth scroll */
html {
    scroll-behavior: auto;
}

/* Notification */
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #4CAF50;
    padding: 15px 20px;
    border-radius: 8px;
    display: none;
    color: white;
    font-weight: bold;
    z-index: 9999;
}

.notification.show {
    display: block;
}
</style>
</head>

<body>

<!-- ✅ NOTIFICATION BOX -->
<div id="adminOrderMessage" class="notification"></div>

<h2>Available Coffees</h2>

<a href="dashboard.php">← Back</a>

<br><br>

<!-- FILTERS -->
<form method="GET">
    <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($search) ?>">

    <select name="category">
        <option value="">All</option>
        <?php while ($cat = $categories->fetch_assoc()): ?>
            <option value="<?= $cat['id'] ?>" <?= $category_filter == $cat['id'] ? 'selected' : '' ?>>
                <?= $cat['name'] ?>
            </option>
        <?php endwhile; ?>
    </select>

    <button type="submit">Filter</button>
</form>

<br>

<!-- MEALS -->
<?php while ($meal = $meals->fetch_assoc()): ?>

<div class="meal-card">

    <?php
    if (!empty($meal['image_url'])) {
        $img = $meal['image_url'];
    } elseif (!empty($meal['image'])) {
        $img = "../images/" . $meal['image'];
    } else {
        $img = "https://source.unsplash.com/300x200/?coffee";
    }
    ?>

    <img src="<?= $img ?>">

    <h4><?= $meal['name'] ?></h4>
    <p>₱<?= number_format($meal['price'], 2) ?></p>
    <p><?= $meal['cat_name'] ?></p>

    <?php if ($meal['status'] == 'Available'): ?>
        <form method="POST" action="add_to_cart.php">
            <input type="hidden" name="meal_id" value="<?= $meal['id'] ?>">
            <button type="submit">Add order</button>
        </form>
    <?php else: ?>
        <button disabled>Unavailable</button>
    <?php endif; ?>

</div>

<?php endwhile; ?>

<!-- ✅ FIX: SCROLL + NOTIFICATION -->
<script>
// Save scroll BEFORE submit
document.addEventListener("submit", function () {
    sessionStorage.setItem("scrollPos", window.scrollY);
});

// Restore scroll EARLY (before full render feel)
(function () {
    const scrollPos = sessionStorage.getItem("scrollPos");

    if (scrollPos !== null) {
        // Force instant scroll before everything paints
        window.scrollTo(0, scrollPos);
        sessionStorage.removeItem("scrollPos");
    }
})();
// Restore scroll + show notification
window.addEventListener("load", function () {
    const scrollPos = sessionStorage.getItem("scrollPos");

    if (scrollPos !== null) {
        setTimeout(() => {
            window.scrollTo(0, parseInt(scrollPos));
        }, 10);

        sessionStorage.removeItem("scrollPos");
    }

    const params = new URLSearchParams(window.location.search);
    const notif = document.getElementById("adminOrderMessage");

    if (notif && params.get("added") === "1") {
        notif.textContent = "🛒 Added to Cart!";
        notif.classList.add("show");

        setTimeout(() => {
            notif.classList.remove("show");
        }, 2000);
    }
});
</script>

</body>
</html>