<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type_id = $_POST['type_id'];

    // Delete the selected coffee type from meals
    $conn->query("DELETE FROM meals WHERE id = $type_id");

    header("Location: manage_categories.php");
    exit;
}
?>
