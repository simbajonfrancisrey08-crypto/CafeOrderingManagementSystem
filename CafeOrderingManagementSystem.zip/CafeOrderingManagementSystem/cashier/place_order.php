<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'cashier') {
    header("Location: ../index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $order_type = $_POST['order_type'] ?? '';
    $user_id = $_SESSION['user_id'];
    $cart = $_SESSION['cart'] ?? [];

    if (empty($cart)) {
        header("Location: cart.php");
        exit;
    }

    // =========================
    // HANDLE TABLE ID SAFELY
    // =========================
    if ($order_type === 'dine-in') {

        if (empty($_POST['table_id'])) {
            die("Error: Please select a table for dine-in.");
        }

        $table_id = (int)$_POST['table_id'];

    } else {
        // take-out = no table
        $table_id = null;
    }

    // =========================
    // COMPUTE TOTAL
    // =========================
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    // =========================
    // INSERT ORDER
    // =========================
    $stmt = $conn->prepare("
        INSERT INTO orders (table_id, user_id, total, order_type, status)
        VALUES (?, ?, ?, ?, 'pending')
    ");

    $stmt->bind_param("iids", $table_id, $user_id, $total, $order_type);

    if (!$stmt->execute()) {
        die("Order insert failed: " . $stmt->error);
    }

    $order_id = $stmt->insert_id;
    $stmt->close();

    // =========================
    // INSERT ORDER ITEMS
    // =========================
    $stmt = $conn->prepare("
        INSERT INTO order_items (order_id, meal_id, quantity, subtotal, price)
        VALUES (?, ?, ?, ?, ?)
    ");

    foreach ($cart as $item) {

        $meal_id = (int)$item['id'];
        $quantity = (int)$item['quantity'];
        $price = (float)$item['price'];
        $subtotal = $price * $quantity;

        $stmt->bind_param("iiidd", $order_id, $meal_id, $quantity, $subtotal, $price);
        $stmt->execute();
    }

    $stmt->close();

    // =========================
    // UPDATE TABLE STATUS
    // =========================
    if ($order_type === 'dine-in' && $table_id) {
        $conn->query("UPDATE tables SET status = 'occupied' WHERE id = $table_id");
    }

    // =========================
    // CLEAR CART
    // =========================
    unset($_SESSION['cart']);

    header("Location: cart.php?success=placed");
    exit;

} else {
    header("Location: cart.php");
    exit;
}