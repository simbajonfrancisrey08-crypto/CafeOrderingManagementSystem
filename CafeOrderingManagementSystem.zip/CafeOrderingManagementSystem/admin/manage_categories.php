<?php 
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
include '../includes/db.php';

// Add category
if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $conn->query("INSERT INTO categories (name) VALUES ('$name')");
    header("Location: manage_categories.php");
    exit;
}

// Delete category with check
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    // Check if meals are using this category
    $check = $conn->query("SELECT * FROM meals WHERE category_id = $id");
    if ($check->num_rows > 0) {
        echo "<script>
                alert('Cannot delete category. It is still assigned to one or more coffee types.');
                window.location.href='manage_categories.php';
              </script>";
        exit;
    }

    // Safe to delete
    $conn->query("DELETE FROM categories WHERE id = $id");
    header("Location: manage_categories.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Categories</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-image: url('../images/dashboard - bg.jpg');
            background-size: cover;
            color: #fff;
            text-align: center;
            padding: 20px;
        }

        ul.types {
            margin: 5px 0 15px 20px;
            padding: 0;
            list-style: circle;
            font-size: 14px;
            color: #555;
        }
        ul.types li {
            margin: 2px 0;
        }
    </style>
</head>
<body>
    <h2>☕ Manage Categories</h2>
    <a href="dashboard.php" 
   style="display: inline-block; padding: 10px 15px; background-color: #f2f2f2; border: 1px solid #ccc; border-radius: 6px; 
          color: black; text-decoration: none; font-weight: bold; font-family: Arial, sans-serif;">
    ← Back to Dashboard
</a>

<br><br>

<!-- Category Form -->
<form method="POST" autocomplete="off" style="color: black; font-family: Arial, sans-serif;">
    <label for="name" style="display: block; margin-bottom: 2px;">Enter New Category Name:</label>
    <input type="text" id="name" name="name" placeholder="e.g. Espresso, Latte" required 
           style="padding: 8px; width: 250px; border: 1px solid #ccc; border-radius: 4px; color: black;">

    <button type="submit" name="add" 
            style="padding: 7px 16px; background-color: #f0f0f0; border: 1px solid #ccc; border-radius: 4px; color: black; cursor: pointer;">
        ➕ Add Category
    </button>
</form>

<br><hr><br>

<table border="1" cellpadding="8" cellspacing="0" style="color: black;">
    <tr>
        <th>Category Name</th>
        <th>Types (Coffee)</th>
        <th>Action</th>
    </tr>
    <?php
    $categories = $conn->query("SELECT * FROM categories");
    while ($row = $categories->fetch_assoc()):
        $cat_id = $row['id'];
        $types = $conn->query("SELECT name, status, id FROM meals WHERE category_id = $cat_id");
    ?>
    <tr>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td>
            <ul class="types">
                <?php if ($types->num_rows > 0): ?>
                    <?php while ($type = $types->fetch_assoc()): ?>
                        <li>
                            <?= htmlspecialchars($type['name']) ?>
                            <span style="color: <?= $type['status'] == 'Available' ? 'green' : 'red' ?>;">
                                (<?= $type['status'] ?>)
                            </span>
                        </li>
                    <?php endwhile; ?>
                <?php else: ?>
                    <li><em>No types yet</em></li>
                <?php endif; ?>
            </ul>

            <!-- Form to delete one coffee type -->
            <form method="POST" action="delete_type.php">
                <select name="type_id" required>
                    <option value="" disabled selected>Select type to delete</option>
                    <?php
                    $types_for_delete = $conn->query("SELECT id, name FROM meals WHERE category_id = $cat_id");
                    while ($type = $types_for_delete->fetch_assoc()):
                    ?>
                        <option value="<?= $type['id'] ?>"><?= htmlspecialchars($type['name']) ?></option>
                    <?php endwhile; ?>
                </select>
                <input type="hidden" name="category_id" value="<?= $cat_id ?>">
                <button type="submit" onclick="return confirm('Delete this coffee type?')">Delete</button>
            </form>
        </td>
        <td>
            <a href="edit_category.php?id=<?= $row['id'] ?>">Edit</a> |
            <a href="manage_categories.php?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this category?')">Delete</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
</body>
</html>
