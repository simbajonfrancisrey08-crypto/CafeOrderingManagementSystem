<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'cashier') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

// Fetch meals and available tables
$meals = $conn->query("SELECT * FROM meals");
$tables = $conn->query("SELECT * FROM tables WHERE status = 'available'");

// Initialize cart
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle add to cart
if (isset($_POST['add'])) {
    $meal_id = $_POST['meal_id'];
    $quantity = $_POST['quantity'];

    $meal = $conn->query("SELECT * FROM meals WHERE id = $meal_id")->fetch_assoc();
    if ($meal) {
        if (!isset($_SESSION['cart'][$meal_id])) {
            $_SESSION['cart'][$meal_id] = [
                'id' => $meal_id,
                'name' => $meal['name'],
                'price' => $meal['price'],
                'quantity' => 0
            ];
        }
        $_SESSION['cart'][$meal_id]['quantity'] += $quantity;
    }
}

// Handle clear cart
if (isset($_POST['clear'])) {
    $_SESSION['cart'] = [];
}
?>

<!DOCTYPE html>
<html>
<head>
<style>
        body {
            font-family: 'Montserrat', sans-serif;
            background:rgba(30, 211, 60, 0.51);
            background-size: cover;
            color: #fff;
            text-align: center;
            padding: 20px;
        }
</style>

    <title>POS - Cashier</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2>Cashier POS</h2>
    <a href="dashboard.php">← Back to Dashboard</a><br><br>

    <?php if (isset($success)) echo "<p style='color:green;'>$success</p>"; ?>

    <form method="POST">
        <label>Select Meal:</label>
        <select name="meal_id" required>
            <?php while ($row = $meals->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>"><?= $row['name'] ?> - ₱<?= $row['price'] ?></option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Quantity:</label>
        <input type="number" name="quantity" value="1" min="1" required><br><br>

        <button type="submit" name="add">Add to Cart</button>
    </form>

    <hr>
    <h3>🛒 Cart</h3>
    <form method="POST">
        <?php
        $total = 0;
        if (!empty($_SESSION['cart'])):
            echo "<ul>";
            foreach ($_SESSION['cart'] as $item):
                $subtotal = $item['price'] * $item['quantity'];
                $total += $subtotal;
                echo "<li>{$item['name']} x {$item['quantity']} = ₱$subtotal</li>";
            endforeach;
            echo "</ul>";
            echo "<p><strong>Total: ₱$total</strong></p>";
        else:
            echo "<p>No items in cart.</p>";
        endif;
        ?>

        <button type="submit" name="clear">Clear Cart</button>
    </form>

    <?php if (!empty($_SESSION['cart'])): ?>
    <hr>
    <h3>Checkout</h3>
    <form method="POST" action="checkout.php">
        <label>Order Type:</label>
        <select name="order_type" required>
            <option value="Dine-in">Dine-in</option>
            <option value="Take-out">Take-out</option>
        </select><br><br>

        <label>Select Table (for Dine-in only):</label>
        <select name="table_id">
            <option value="">-- Select Table --</option>
            <?php while ($row = $tables->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>">
                    <?= $row['table_name'] ?> (Table #<?= $row['table_number'] ?>)
                </option>
            <?php endwhile; ?>
        </select><br><br>

        <button type="submit" name="checkout">Place Order</button>
    </form>
    <?php endif; ?>
</body>
</html>
