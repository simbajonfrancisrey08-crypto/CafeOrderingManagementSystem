<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
include '../includes/db.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$meal = $conn->query("SELECT * FROM meals WHERE id = $id")->fetch_assoc();
if (!$meal) {
    echo "Meal not found.";
    exit;
}

$categories = $conn->query("SELECT * FROM categories");

if (isset($_POST['update'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $price = $_POST['price'];
    $category_id = $_POST['category_id'];
    $status = $_POST['status']; // new

    $conn->query("UPDATE meals 
                  SET name='$name', price='$price', category_id='$category_id', status='$status' 
                  WHERE id=$id");

    header("Location: manage_meals.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Meal</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background: rgb(249, 253, 253);
            background-size: cover;
            color: #030303;
            text-align: center;
            padding: 20px;
        }
    </style>
</head>
<body>
    <h2>Edit Coffee</h2>
    <a href="manage_meals.php">← Back</a><br><br>

    <form method="POST">
        <label for="name">Coffee Name</label>
        <input type="text" name="name" id="name" value="<?= htmlspecialchars($meal['name']) ?>" required><br>

        <label for="price">Price (₱)</label>
        <input type="number" name="price" id="price" step="0.01" value="<?= $meal['price'] ?>" required><br>

        <label for="category_id">Category</label>
        <select name="category_id" id="category_id" required>
            <?php while($cat = $categories->fetch_assoc()): ?>
                <option value="<?= $cat['id'] ?>" <?= $cat['id'] == $meal['category_id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($cat['name']) ?>
                </option>
            <?php endwhile; ?>
        </select><br>

        <label for="status">Availability</label>
        <select name="status" id="status" required>
            <option value="Available" <?= $meal['status'] == 'Available' ? 'selected' : '' ?>>Available</option>
            <option value="Not Available" <?= $meal['status'] == 'Not Available' ? 'selected' : '' ?>>Not Available</option>
        </select><br>

        <button type="submit" name="update">Update Meal</button>
    </form>
</body>
</html>
