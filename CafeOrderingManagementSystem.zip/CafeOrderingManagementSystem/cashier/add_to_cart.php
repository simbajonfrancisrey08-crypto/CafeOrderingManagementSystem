<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'cashier') {
    header("Location: ../index.php");
    exit;
}

if (!isset($_POST['meal_id']) || !is_numeric($_POST['meal_id'])) {
    header("Location: cashier_meals.php");
    exit;
}

$meal_id = (int) $_POST['meal_id'];

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

include '../includes/db.php';

if (isset($_SESSION['cart'][$meal_id])) {
    $_SESSION['cart'][$meal_id]['quantity']++;
} else {

    $query = "SELECT id, name, price, image FROM meals WHERE id = $meal_id LIMIT 1";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $meal = $result->fetch_assoc();

        $_SESSION['cart'][$meal_id] = [
            'id' => $meal['id'],
            'name' => $meal['name'],
            'price' => $meal['price'],
            'quantity' => 1,
            'image' => $meal['image']
        ];
    }
}

$conn->close();

// ✅ Redirect with notification flag
header("Location: cashier_meals.php?added=1");
exit;
?>