<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'cashier') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

// Fetch all orders (latest first)
$orders = $conn->query("SELECT orders.*, users.username 
                        FROM orders 
                        LEFT JOIN users ON orders.user_id = users.id 
                        ORDER BY orders.created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
<style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-image: url('../images/dashboard - bg.jpg');
            background-size: cover;
            color: #fff;
            text-align: center;
            padding: 20px;
        }
</style>
    <title>View Orders - Cashier</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2>View Orders</h2>
    <a href="dashboard.php">← Back to Dashboard</a><br><br>

    <?php if ($orders->num_rows > 0): ?>
        <table border="1" cellpadding="8" cellspacing="0">
            <tr>
                <th>Cashier</th>
                <th>Type</th>
                <th>Table #</th>
                <th>Total (₱)</th>
                <th>Date</th>
                <th>Details</th>
            </tr>
            <?php while ($row = $orders->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['username'] ?></td>
                    <td><?= ucfirst($row['order_type']) ?></td>
                    <td><?= $row['table_id'] ?: '-' ?></td>
                    <td><?= number_format($row['total'], 2) ?></td>
                    <td><?= $row['created_at'] ?></td>
                    <td><a href="order_details.php?id=<?= $row['id'] ?>">View</a></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No orders found.</p>
    <?php endif; ?>
</body>
</html>
