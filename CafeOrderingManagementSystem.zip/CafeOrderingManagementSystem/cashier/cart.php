<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'cashier') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

$cart = $_SESSION['cart'] ?? [];
$total = 0;

// Fetch available tables
$tables = $conn->query("SELECT * FROM tables WHERE status = 'available' ORDER BY table_name ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cart</title>
    <link rel="stylesheet" href="../css/style.css">

    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-image: url('../images/dashboard - bg.jpg');
            background-size: cover;
            color: #fff;
            text-align: center;
            padding: 20px;
        }

        table {
            width: 90%;
            margin: auto;
            background: #fff;
            color: #000;
            border-collapse: collapse;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #2f9e44;
            color: white;
        }

        img {
            border-radius: 6px;
        }

        button {
            padding: 6px 14px;
            border: none;
            background: #28a745;
            color: white;
            cursor: pointer;
            border-radius: 6px;
        }

        button:hover {
            background: #218838;
        }

        select, label {
            margin: 8px;
            padding: 6px;
            border-radius: 4px;
            color: black;
        }

        .table-select {
            display: none;
        }
    </style>
</head>

<body>

<h2>🛒 Current Order</h2>
<a href="cashier_meals.php">← Back to Coffees</a>

<br><br>

<?php if (count($cart) === 0): ?>
    <p>Your cart is empty.</p>
<?php else: ?>

<table>
    <tr>
        <th>Image</th>
        <th>Coffee Name</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Subtotal</th>
        <th>Action</th>
    </tr>

    <?php foreach ($cart as $item): 
        $meal_id = $item['id'];
        $subtotal = $item['price'] * $item['quantity'];
        $total += $subtotal;

        // GET IMAGE FROM DATABASE
        $imgResult = $conn->query("SELECT image, image_url, name FROM meals WHERE id = $meal_id");
        $imgRow = $imgResult->fetch_assoc();

        if (!empty($imgRow['image_url'])) {
            $img = $imgRow['image_url']; // Unsplash
        } elseif (!empty($imgRow['image'])) {
            $img = "../images/" . $imgRow['image']; // uploaded image
        } else {
            $img = "https://source.unsplash.com/80x80/?" . urlencode($imgRow['name'] . " coffee");
        }
    ?>

    <tr>
        <td>
            <img src="<?= $img ?>" width="60" height="60" style="object-fit: cover;">
        </td>

        <td><?= htmlspecialchars($item['name']) ?></td>
        <td>₱<?= number_format($item['price'], 2) ?></td>
        <td><?= $item['quantity'] ?></td>
        <td>₱<?= number_format($subtotal, 2) ?></td>

        <td>
            <form action="remove_from_cart.php" method="POST">
                <input type="hidden" name="meal_id" value="<?= $item['id'] ?>">
                <button type="submit">Remove</button>
            </form>
        </td>
    </tr>

    <?php endforeach; ?>
</table>

<br>

<h3>Total: ₱<?= number_format($total, 2) ?></h3>

<!-- ORDER TYPE -->
<form action="place_order.php" method="POST">

    <label>Order Type:</label>
    <select name="order_type" id="order_type" onchange="toggleTable()" required>
        <option value="">-- Select --</option>
        <option value="dine-in">Dine-In</option>
        <option value="take-out">Take-Out</option>
    </select>

    <div id="tableSelect" class="table-select">
        <label>Table:</label>
        <select name="table_id">
            <option value="">-- Select Table --</option>
            <?php while ($t = $tables->fetch_assoc()): ?>
                <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['table_name']) ?></option>
            <?php endwhile; ?>
        </select>
    </div>

    <br><br>
    <button type="submit">🧾 Place Order</button>
</form>

<br>

<form action="clear_cart.php" method="POST">
    <button type="submit">🗑 Clear Order</button>
</form>

<?php endif; ?>

<script>
function toggleTable() {
    let type = document.getElementById("order_type").value;
    document.getElementById("tableSelect").style.display =
        type === "dine-in" ? "block" : "none";
}
</script>

</body>
</html>