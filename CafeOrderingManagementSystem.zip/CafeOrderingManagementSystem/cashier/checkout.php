<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'cashier') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header("Location: pos.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    $user_id = $_SESSION['user_id'];
    $order_type = $_POST['order_type'];
    $table_id = !empty($_POST['table_id']) ? (int)$_POST['table_id'] : null;
    $total = 0;

    foreach ($cart as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    // Validate table_id only if dine-in
    if ($order_type === 'Dine-in' && !$table_id) {
        header("Location: pos.php?error=NoTableSelected");
        exit;
    }

    // Prepare statement to insert order
    $stmt = $conn->prepare("INSERT INTO orders (user_id, order_type, table_id, total, status, created_at) VALUES (?, ?, ?, ?, 'Pending', NOW())");
    $stmt->bind_param("isid", $user_id, $order_type, $table_id, $total);
    $stmt->execute();
    $order_id = $stmt->insert_id;
    $stmt->close();

    // Insert each item in the cart
    $stmt = $conn->prepare("INSERT INTO order_items (order_id, meal_id, quantity, price) VALUES (?, ?, ?, ?)");
    foreach ($cart as $item) {
        $stmt->bind_param("iiid", $order_id, $item['id'], $item['quantity'], $item['price']);
        $stmt->execute();
    }
    $stmt->close();

    // If dine-in, mark table as occupied
    if ($order_type === 'Dine-in' && $table_id) {
        $conn->query("UPDATE tables SET status = 'occupied' WHERE id = $table_id");
    }

    unset($_SESSION['cart']); // Clear cart after checkout
    header("Location: pos.php?success=1");
    exit;
}
?>
