<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
include '../includes/db.php';

// Add Table
if (isset($_POST['add'])) {
    $table_name = $conn->real_escape_string($_POST['table_name']);
    $conn->query("INSERT INTO tables (table_name, status) VALUES ('$table_name', 'available')");
    header("Location: manage_tables.php");
    exit;
}

// Delete Table
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $conn->query("DELETE FROM tables WHERE id = $id");
    header("Location: manage_tables.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Tables</title>
    <link rel="stylesheet" href="../css/style.css">

    <style>
        body {
            font-family: 'Montserrat', sans-serif;
           background-image: url('../images/dashboard - bg.jpg');
            background-size: cover;
            color: #fff;
            text-align: center;
            padding: 20px;
        }
        ul.types {
            margin: 5px 0 15px 20px;
            padding: 0;
            list-style: circle;
            font-size: 14px;
            color: #555;
        }
        ul.types li {
            margin: 2px 0;
        }
    </style>
</head>
<body>
    <h2>🍽️ Manage Tables</h2>
    <a href="dashboard.php" 
   style="display: inline-block; padding: 10px 15px; background-color: #f2f2f2; border: 1px solid #ccc; border-radius: 6px; 
          color: black; text-decoration: none; font-weight: bold; font-family: Arial, sans-serif;">
    ← Back to Dashboard
</a>
<br><br>

<form method="POST">
    <input type="text" name="table_name" placeholder="Table Name / No." required>
    <button type="submit" name="add" 
            style="padding: 7px 16px; background-color: #f0f0f0; border: 1px solid #ccc; border-radius: 4px; color: black; cursor: pointer;">
        ➕ Add Table
    </button>
</form>


    <br><hr><br>

    <table border="1" cellpadding="8" cellspacing="0" style="color: black;">
        <tr>
            <th>Table Name</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php
        $tables = $conn->query("SELECT * FROM tables ORDER BY id ASC");
        while ($row = $tables->fetch_assoc()):
        ?>
        <tr>
            <td><?= htmlspecialchars($row['table_name']) ?></td>
            <td><?= $row['status'] ?></td>
            <td>
                <a href="edit_table.php?id=<?= $row['id'] ?>">Edit</a> |
                <a href="manage_tables.php?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this table?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
