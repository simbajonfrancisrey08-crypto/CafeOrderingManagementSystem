<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

// Fetch meals
$meals = $conn->query("SELECT * FROM meals");

// Initialize cart
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle add to cart
if (isset($_POST['add'])) {
    $meal_id = $_POST['meal_id'];
    $quantity = $_POST['quantity'];

    $meal = $conn->query("SELECT * FROM meals WHERE id = $meal_id")->fetch_assoc();
    if ($meal) {
        if (!isset($_SESSION['cart'][$meal_id])) {
            $_SESSION['cart'][$meal_id] = [
                'name' => $meal['name'],
                'price' => $meal['price'],
                'quantity' => 0
            ];
        }
        $_SESSION['cart'][$meal_id]['quantity'] += $quantity;
    }
}

// Handle clear cart
if (isset($_POST['clear'])) {
    $_SESSION['cart'] = [];
}

// Handle checkout
if (isset($_POST['checkout'])) {
    $_SESSION['cart'] = [];
    $success = "Order placed successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>POS - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2>Admin POS</h2>
    <a href="dashboard.php">← Back to Dashboard</a><br><br>

    <?php if (isset($success)) echo "<p style='color:green;'>$success</p>"; ?>

    <form method="POST">
        <label>Select Meal:</label>
        <select name="meal_id" required>
            <?php while ($row = $meals->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>"><?= $row['name'] ?> - ₱<?= $row['price'] ?></option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Quantity:</label>
        <input type="number" name="quantity" value="1" min="1" required><br><br>

        <button type="submit" name="add">Add to Cart</button>
    </form>

    <hr>
    <h3>🛒 Cart</h3>
    <form method="POST">
        <?php
        $total = 0;
        if (!empty($_SESSION['cart'])):
            echo "<ul>";
            foreach ($_SESSION['cart'] as $item):
                $subtotal = $item['price'] * $item['quantity'];
                $total += $subtotal;
                echo "<li>{$item['name']} x {$item['quantity']} = ₱$subtotal</li>";
            endforeach;
            echo "</ul>";
            echo "<p><strong>Total: ₱$total</strong></p>";
        else:
            echo "<p>No items in cart.</p>";
        endif;
        ?>

        <button type="submit" name="checkout">Checkout</button>
        <button type="submit" name="clear">Clear Cart</button>
    </form>
</body>
</html>
