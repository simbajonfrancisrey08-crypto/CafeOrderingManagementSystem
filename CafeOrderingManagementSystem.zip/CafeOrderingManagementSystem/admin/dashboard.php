<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
include '../includes/db.php';

// Count summaries
$mealCount = $conn->query("SELECT COUNT(*) as total FROM meals")->fetch_assoc()['total'];
$categoryCount = $conn->query("SELECT COUNT(*) as total FROM categories")->fetch_assoc()['total'];
$tableCount = $conn->query("SELECT COUNT(*) as total FROM tables")->fetch_assoc()['total'];
$userCount = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$orderCount = $conn->query("SELECT COUNT(*) as total FROM orders")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-image: url('../images/dashboard - bg.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #fff;
            text-align: center;
            padding: 20px;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: whitesmoke;
            border-bottom: 1px solid #ddd;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .clock {
            font-size: 15px;
            color: #2c3e50;
            font-weight: 500;
        }

        .profile-dropdown {
            position: relative;
            display: inline-block;
        }

        .profile-btn {
            background-color: #3498db;
            color: white;
            padding: 10px 16px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .profile-btn:hover {
            background-color: #2980b9;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 8px;
            overflow: hidden;
        }

        .dropdown-content a {
            color: #2c3e50;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            font-weight: bold;
        }

        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .profile-dropdown:hover .dropdown-content {
            display: block;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            background: rgba(255, 255, 255, 0.4);
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            color: #222;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease-in-out;
        }

        h1 {
            color:rgb(19, 16, 2);
            margin-bottom: 10px;
        }

        h3 {
            color:rgba(6, 5, 8, 0.55);
            margin-bottom: 10px;
        }

        nav {
            margin: 20px 0;
        }

        nav a {
            background:rgb(236, 235, 233);
            color: black;
            padding: 10px 15px;
            margin: 5px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.3s ease;
            display: inline-block;
        }

        nav a:hover {
            background: #1c5981;
        }

        .summary {
            text-align: left;
            margin-top: 20px;
        }

        .summary li {
            background:rgba(82, 104, 70, 0.64);
            color: white;
            margin: 8px 0;
            padding: 10px;
            border-radius: 6px;
            list-style: none;
        }

        .emoji {
            font-size: 24px;
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="top-bar">
        <div class="clock" id="clock">⏰ Loading...</div>
        <div class="profile-dropdown">
            <button class="profile-btn">👤 <?= htmlspecialchars($_SESSION['username']); ?> ▼</button>
            <div class="dropdown-content">
                <a href="../logout.php">🚪 Logout</a>
            </div>
        </div>
    </div>

    <div class="container">
        <h1>👋 Welcome, Admin <?= htmlspecialchars($_SESSION['username']); ?>!</h1>

        <nav>
            <a href="manage_meals.php">🍽️ Manage Coffees</a>
            <a href="manage_categories.php">📂 Categories</a>
            <a href="manage_tables.php">🪑 Tables</a>
            <a href="manage_orders.php">🧾 Orders</a>
            <a href="manage_users.php">👥 Users</a>
        </nav>

        <h3>📊 Dashboard Overview</h3>
        <ul class="summary">
            <li><span class="emoji">🍔</span>Total Coffees: <?= $mealCount ?></li>
            <li><span class="emoji">📁</span>Total Categories: <?= $categoryCount ?></li>
            <li><span class="emoji">🪑</span>Total Tables: <?= $tableCount ?></li>
            <li><span class="emoji">👤</span>Total Users: <?= $userCount ?></li>
            <li><span class="emoji">🧾</span>Total Orders: <?= $orderCount ?></li>
        </ul>

        <p>Use the menu above to manage the system.</p>
    </div>

    <script>
    function updateClock() {
        const now = new Date();
        const time = now.toLocaleTimeString();
        const date = now.toLocaleDateString(undefined, { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
        document.getElementById('clock').textContent = `📅 ${date} | ⏰ ${time}`;
    }
    setInterval(updateClock, 1000);
    updateClock();
    </script>
</body>
</html>
