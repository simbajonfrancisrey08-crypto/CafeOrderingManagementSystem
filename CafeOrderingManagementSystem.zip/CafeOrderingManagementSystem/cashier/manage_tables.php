<!-- <?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'cashier') {
    header("Location: ../index.php");
    exit;
}

include '../includes/db.php';

// Fetch all tables
$tables = $conn->query("SELECT * FROM tables ORDER BY table_number ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Tables - Cashier</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2>Manage Tables</h2>
    <a href="dashboard.php">← Back to Dashboard</a><br><br>

    <?php if ($tables->num_rows > 0): ?>
        <table border="1" cellpadding="8" cellspacing="0">
            <tr>
                <th>Table Number</th>
                <th>Status</th>
            </tr>
            <?php while ($table = $tables->fetch_assoc()): ?>
                <tr>
                    <td><?= isset($table['table_number']) ? $table['table_number'] : '-' ?></td>
                    <td><?= isset($table['status']) ? ucfirst($table['status']) : '-' ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No tables found.</p>
    <?php endif; ?>
</body>
</html> -->
