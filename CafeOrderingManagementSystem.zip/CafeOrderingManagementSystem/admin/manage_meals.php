<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}
include '../includes/db.php';

/* ADD MEAL */
if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category_id = $_POST['category_id'];
    $status = $_POST['status'];
    $image_url = $_POST['image_url'];

    $imageName = "";

    // Optional upload (still supported)
    if (!empty($_FILES['image']['name'])) {
        $imageName = str_replace(' ', '_', $_FILES['image']['name']);
        $tmp = $_FILES['image']['tmp_name'];
        move_uploaded_file($tmp, "../images/" . $imageName);
    }

    $conn->query("INSERT INTO meals (name, price, category_id, image, image_url, status)
    VALUES ('$name', '$price', '$category_id', '$imageName', '$image_url', '$status')");

    header("Location: manage_meals.php");
    exit;
}

/* DELETE */
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM meals WHERE id=$id");
    header("Location: manage_meals.php");
    exit;
}

/* CATEGORIES */
$categories = $conn->query("SELECT * FROM categories");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Meals</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: Arial;
             background-image: url('../images/dashboard - bg.jpg');
            color: #fff;
            text-align: center;
        }

        table {
            margin: auto;
            background: #fff;
            color: #000;
            border-radius: 10px;
        }

        th, td {
            padding: 10px;
        }

        img {
            border-radius: 8px;
        }

        input, select, button {
            padding: 8px;
            margin: 5px;
        }

        #results img {
            width: 100px;
            cursor: pointer;
            border-radius: 8px;
            transition: 0.2s;
        }

        #results img:hover {
            transform: scale(1.1);
        }
    </style>
</head>

<body>

<h2>Manage Coffees</h2>

<a href="dashboard.php" 
   style="display: inline-block; padding: 10px 15px; background-color: #f2f2f2; border: 1px solid #ccc; border-radius: 6px; 
          color: black; text-decoration: none; font-weight: bold; font-family: Arial, sans-serif;">
    ← Back to Dashboard
</a>
<br><br>

<!-- ADD FORM -->
<form method="POST" enctype="multipart/form-data">

    <input type="text" name="name" placeholder="Coffee Name" required>
    <input type="number" step="0.01" name="price" placeholder="Price" required>

    <select name="category_id" required>
        <option value="">Select Category</option>
        <?php while($row = $categories->fetch_assoc()): ?>
            <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
        <?php endwhile; ?>
    </select>

    <select name="status">
        <option value="Available">Available</option>
        <option value="Not Available">Not Available</option>
    </select>

    <!-- MANUAL UPLOAD (OPTIONAL) -->
    <input type="file" name="image">

    <br><br>

    <!-- UNSPLASH SEARCH -->
    <input type="text" id="search" placeholder="Search image (coffee, latte...)">
    <button type="button" onclick="searchImages()">Search Unsplash</button>

    <div id="results"></div>

    <input type="hidden" name="image_url" id="image_url">

    <br>

    <button type="submit" name="add">Add</button>

</form>

<hr>

<!-- TABLE -->
<table border="1">
<tr>
    <th>Image</th>
    <th>Name</th>
    <th>Price</th>
    <th>Category</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php
$meals = $conn->query("
SELECT meals.*, categories.name AS cat_name
FROM meals
JOIN categories ON meals.category_id = categories.id
");

while($row = $meals->fetch_assoc()):

// IMAGE PRIORITY
if (!empty($row['image_url'])) {
    $img = $row['image_url'];
} else {
    $img = "../images/" . $row['image'];
}
?>

<tr>

    <td>
        <img src="<?= $img ?>" width="80">
    </td>

    <td><?= $row['name'] ?></td>
    <td>₱<?= number_format($row['price'], 2) ?></td>
    <td><?= $row['cat_name'] ?></td>
    <td><?= $row['status'] ?></td>

    <td>
        <a href="edit_meal.php?id=<?= $row['id'] ?>">Edit</a> |
        <a href="manage_meals.php?delete=<?= $row['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
    </td>
</tr>

<?php endwhile; ?>

</table>

<script>
async function searchImages() {
    let query = document.getElementById("search").value;

    let res = await fetch("https://api.unsplash.com/search/photos?query=" + query + "&per_page=6&client_id=cngZ7V0SK4zqZMjGWpIybWZzbw3Km8z64q7sn-xrR9E");
    let data = await res.json();

    let results = document.getElementById("results");
    results.innerHTML = "";

    data.results.forEach(img => {
        let image = document.createElement("img");
        image.src = img.urls.small;

        image.onclick = function() {
            document.getElementById("image_url").value = img.urls.small;
            alert("Image selected!");
        };

        results.appendChild(image);
    });
}
</script>

</body>
</html>